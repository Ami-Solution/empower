--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE client (
    id integer NOT NULL,
    "desc" text
);


--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE client_id_seq OWNED BY client.id;


--
-- Name: consumption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE consumption (
    id integer NOT NULL,
    client_id smallint,
    day smallint,
    prd smallint,
    kwh numeric
);


--
-- Name: consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumption_id_seq OWNED BY consumption.id;


--
-- Name: meter_load; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE meter_load (
    id integer NOT NULL,
    ts timestamp with time zone,
    src_filename text,
    nb_days smallint,
    nb_prds_per_day smallint,
    date_from date,
    format_id smallint,
    client_id integer
);


--
-- Name: meter_load_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE meter_load_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meter_load_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE meter_load_id_seq OWNED BY meter_load.id;


--
-- Name: staging_agl1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_agl1 (
    id integer NOT NULL,
    accountnumber text,
    nmi text,
    devicenumber text,
    devicetype text,
    registercode text,
    ratetypedescription text,
    startdate text,
    enddate text,
    profilereadvalue text,
    registerreadvalue text,
    qualityflag text
);


--
-- Name: staging_agl1_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_agl1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_agl1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_agl1_id_seq OWNED BY staging_agl1.id;


--
-- Name: staging_click; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_click (
    id integer NOT NULL,
    c1 text,
    date text,
    p1 numeric,
    p2 numeric,
    p3 numeric,
    p4 numeric,
    p5 numeric,
    p6 numeric,
    p7 numeric,
    p8 numeric,
    p9 numeric,
    p10 numeric,
    p11 numeric,
    p12 numeric,
    p13 numeric,
    p14 numeric,
    p15 numeric,
    p16 numeric,
    p17 numeric,
    p18 numeric,
    p19 numeric,
    p20 numeric,
    p21 numeric,
    p22 numeric,
    p23 numeric,
    p24 numeric,
    p25 numeric,
    p26 numeric,
    p27 numeric,
    p28 numeric,
    p29 numeric,
    p30 numeric,
    p31 numeric,
    p32 numeric,
    p33 numeric,
    p34 numeric,
    p35 numeric,
    p36 numeric,
    p37 numeric,
    p38 numeric,
    p39 numeric,
    p40 numeric,
    p41 numeric,
    p42 numeric,
    p43 numeric,
    p44 numeric,
    p45 numeric,
    p46 numeric,
    p47 numeric,
    p48 numeric,
    c2 text,
    c3 text,
    c4 text,
    c5 text
);


--
-- Name: staging_click_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_click_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_click_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_click_id_seq OWNED BY staging_click.id;


--
-- Name: staging_lumo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_lumo (
    id integer NOT NULL,
    nmi text,
    intervalreaddate text,
    meterserialnumber text,
    energydirection text,
    uom text,
    registerid text,
    controlload text,
    p1 numeric,
    t1 text,
    p2 numeric,
    t2 text,
    p3 numeric,
    t3 text,
    p4 numeric,
    t4 text,
    p5 numeric,
    t5 text,
    p6 numeric,
    t6 text,
    p7 numeric,
    t7 text,
    p8 numeric,
    t8 text,
    p9 numeric,
    t9 text,
    p10 numeric,
    t10 text,
    p11 numeric,
    t11 text,
    p12 numeric,
    t12 text,
    p13 numeric,
    t13 text,
    p14 numeric,
    t14 text,
    p15 numeric,
    t15 text,
    p16 numeric,
    t16 text,
    p17 numeric,
    t17 text,
    p18 numeric,
    t18 text,
    p19 numeric,
    t19 text,
    p20 numeric,
    t20 text,
    p21 numeric,
    t21 text,
    p22 numeric,
    t22 text,
    p23 numeric,
    t23 text,
    p24 numeric,
    t24 text,
    p25 numeric,
    t25 text,
    p26 numeric,
    t26 text,
    p27 numeric,
    t27 text,
    p28 numeric,
    t28 text,
    p29 numeric,
    t29 text,
    p30 numeric,
    t30 text,
    p31 numeric,
    t31 text,
    p32 numeric,
    t32 text,
    p33 numeric,
    t33 text,
    p34 numeric,
    t34 text,
    p35 numeric,
    t35 text,
    p36 numeric,
    t36 text,
    p37 numeric,
    t37 text,
    p38 numeric,
    t38 text,
    p39 numeric,
    t39 text,
    p40 numeric,
    t40 text,
    p41 numeric,
    t41 text,
    p42 numeric,
    t42 text,
    p43 numeric,
    t43 text,
    p44 numeric,
    t44 text,
    p45 numeric,
    t45 text,
    p46 numeric,
    t46 text,
    p47 numeric,
    t47 text,
    p48 numeric,
    t48 text,
    p49 numeric,
    t49 text,
    p50 numeric,
    t50 text,
    p51 numeric,
    t51 text,
    p52 numeric,
    t52 text,
    p53 numeric,
    t53 text,
    p54 numeric,
    t54 text,
    p55 numeric,
    t55 text,
    p56 numeric,
    t56 text,
    p57 numeric,
    t57 text,
    p58 numeric,
    t58 text,
    p59 numeric,
    t59 text,
    p60 numeric,
    t60 text,
    p61 numeric,
    t61 text,
    p62 numeric,
    t62 text,
    p63 numeric,
    t63 text,
    p64 numeric,
    t64 text,
    p65 numeric,
    t65 text,
    p66 numeric,
    t66 text,
    p67 numeric,
    t67 text,
    p68 numeric,
    t68 text,
    p69 numeric,
    t69 text,
    p70 numeric,
    t70 text,
    p71 numeric,
    t71 text,
    p72 numeric,
    t72 text,
    p73 numeric,
    t73 text,
    p74 numeric,
    t74 text,
    p75 numeric,
    t75 text,
    p76 numeric,
    t76 text,
    p77 numeric,
    t77 text,
    p78 numeric,
    t78 text,
    p79 numeric,
    t79 text,
    p80 numeric,
    t80 text,
    p81 numeric,
    t81 text,
    p82 numeric,
    t82 text,
    p83 numeric,
    t83 text,
    p84 numeric,
    t84 text,
    p85 numeric,
    t85 text,
    p86 numeric,
    t86 text,
    p87 numeric,
    t87 text,
    p88 numeric,
    t88 text,
    p89 numeric,
    t89 text,
    p90 numeric,
    t90 text,
    p91 numeric,
    t91 text,
    p92 numeric,
    t92 text,
    p93 numeric,
    t93 text,
    p94 numeric,
    t94 text,
    p95 numeric,
    t95 text,
    p96 numeric,
    t96 text
);


--
-- Name: staging_lumo_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_lumo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_lumo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_lumo_id_seq OWNED BY staging_lumo.id;


--
-- Name: staging_notsure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_notsure (
    id integer NOT NULL,
    nmi text,
    day text,
    "interval" text,
    endtime text,
    kwh text,
    net_kwh text,
    kvarh text,
    net_kvarh text,
    kva text,
    kw text,
    quality_status text,
    timeslice text,
    peak text,
    offpeak text,
    shoulder text
);


--
-- Name: staging_notsure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_notsure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_notsure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_notsure_id_seq OWNED BY staging_notsure.id;


--
-- Name: staging_origin1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_origin1 (
    id integer NOT NULL,
    content text
);


--
-- Name: staging_origin1_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_origin1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_origin1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_origin1_id_seq OWNED BY staging_origin1.id;


--
-- Name: staging_origin2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_origin2 (
    id integer NOT NULL,
    nmi text,
    meterserialnumber text,
    congen text,
    date text,
    estimated text,
    p1 numeric,
    p2 numeric,
    p3 numeric,
    p4 numeric,
    p5 numeric,
    p6 numeric,
    p7 numeric,
    p8 numeric,
    p9 numeric,
    p10 numeric,
    p11 numeric,
    p12 numeric,
    p13 numeric,
    p14 numeric,
    p15 numeric,
    p16 numeric,
    p17 numeric,
    p18 numeric,
    p19 numeric,
    p20 numeric,
    p21 numeric,
    p22 numeric,
    p23 numeric,
    p24 numeric,
    p25 numeric,
    p26 numeric,
    p27 numeric,
    p28 numeric,
    p29 numeric,
    p30 numeric,
    p31 numeric,
    p32 numeric,
    p33 numeric,
    p34 numeric,
    p35 numeric,
    p36 numeric,
    p37 numeric,
    p38 numeric,
    p39 numeric,
    p40 numeric,
    p41 numeric,
    p42 numeric,
    p43 numeric,
    p44 numeric,
    p45 numeric,
    p46 numeric,
    p47 numeric,
    p48 numeric
);


--
-- Name: staging_origin2_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_origin2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_origin2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_origin2_id_seq OWNED BY staging_origin2.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY client ALTER COLUMN id SET DEFAULT nextval('client_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumption ALTER COLUMN id SET DEFAULT nextval('consumption_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY meter_load ALTER COLUMN id SET DEFAULT nextval('meter_load_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_agl1 ALTER COLUMN id SET DEFAULT nextval('staging_agl1_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_click ALTER COLUMN id SET DEFAULT nextval('staging_click_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_lumo ALTER COLUMN id SET DEFAULT nextval('staging_lumo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_notsure ALTER COLUMN id SET DEFAULT nextval('staging_notsure_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin1 ALTER COLUMN id SET DEFAULT nextval('staging_origin1_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin2 ALTER COLUMN id SET DEFAULT nextval('staging_origin2_id_seq'::regclass);


--
-- Name: pk_client; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY client
    ADD CONSTRAINT pk_client PRIMARY KEY (id);


--
-- Name: pk_consumption; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumption
    ADD CONSTRAINT pk_consumption PRIMARY KEY (id);


--
-- Name: pk_meter_load; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY meter_load
    ADD CONSTRAINT pk_meter_load PRIMARY KEY (id);


--
-- Name: pk_staging_agl1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_agl1
    ADD CONSTRAINT pk_staging_agl1 PRIMARY KEY (id);


--
-- Name: pk_staging_click; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_click
    ADD CONSTRAINT pk_staging_click PRIMARY KEY (id);


--
-- Name: pk_staging_lumo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_lumo
    ADD CONSTRAINT pk_staging_lumo PRIMARY KEY (id);


--
-- Name: pk_staging_notsure; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_notsure
    ADD CONSTRAINT pk_staging_notsure PRIMARY KEY (id);


--
-- Name: pk_staging_origin1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin1
    ADD CONSTRAINT pk_staging_origin1 PRIMARY KEY (id);


--
-- Name: pk_staging_origin2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin2
    ADD CONSTRAINT pk_staging_origin2 PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

