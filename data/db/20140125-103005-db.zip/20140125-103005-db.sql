--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE client (
    id integer NOT NULL,
    "desc" text
);


--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE client_id_seq OWNED BY client.id;


--
-- Name: consumption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE consumption (
    id integer NOT NULL,
    client_id smallint,
    day smallint,
    prd smallint,
    kwh numeric
);


--
-- Name: consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumption_id_seq OWNED BY consumption.id;


--
-- Name: meter_load; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE meter_load (
    id integer NOT NULL,
    ts timestamp with time zone,
    src_filename text,
    nb_days smallint,
    nb_prds_per_day smallint,
    date_from date,
    format_id smallint,
    client_id integer
);


--
-- Name: meter_load_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE meter_load_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meter_load_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE meter_load_id_seq OWNED BY meter_load.id;


--
-- Name: staging_agl1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_agl1 (
    id integer NOT NULL,
    accountnumber text,
    nmi text,
    devicenumber text,
    devicetype text,
    registercode text,
    ratetypedescription text,
    startdate text,
    enddate text,
    profilereadvalue text,
    registerreadvalue text,
    qualityflag text
);


--
-- Name: staging_agl1_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_agl1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_agl1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_agl1_id_seq OWNED BY staging_agl1.id;


--
-- Name: staging_origin1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_origin1 (
    id integer NOT NULL,
    content text
);


--
-- Name: staging_origin1_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_origin1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_origin1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_origin1_id_seq OWNED BY staging_origin1.id;


--
-- Name: staging_origin2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE staging_origin2 (
    id integer NOT NULL,
    nmi text,
    meterserialnumber text,
    congen text,
    date text,
    estimated text,
    p1 numeric,
    p2 numeric,
    p3 numeric,
    p4 numeric,
    p5 numeric,
    p6 numeric,
    p7 numeric,
    p8 numeric,
    p9 numeric,
    p10 numeric,
    p11 numeric,
    p12 numeric,
    p13 numeric,
    p14 numeric,
    p15 numeric,
    p16 numeric,
    p17 numeric,
    p18 numeric,
    p19 numeric,
    p20 numeric,
    p21 numeric,
    p22 numeric,
    p23 numeric,
    p24 numeric,
    p25 numeric,
    p26 numeric,
    p27 numeric,
    p28 numeric,
    p29 numeric,
    p30 numeric,
    p31 numeric,
    p32 numeric,
    p33 numeric,
    p34 numeric,
    p35 numeric,
    p36 numeric,
    p37 numeric,
    p38 numeric,
    p39 numeric,
    p40 numeric,
    p41 numeric,
    p42 numeric,
    p43 numeric,
    p44 numeric,
    p45 numeric,
    p46 numeric,
    p47 numeric,
    p48 numeric
);


--
-- Name: staging_origin2_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE staging_origin2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staging_origin2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE staging_origin2_id_seq OWNED BY staging_origin2.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY client ALTER COLUMN id SET DEFAULT nextval('client_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumption ALTER COLUMN id SET DEFAULT nextval('consumption_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY meter_load ALTER COLUMN id SET DEFAULT nextval('meter_load_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_agl1 ALTER COLUMN id SET DEFAULT nextval('staging_agl1_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin1 ALTER COLUMN id SET DEFAULT nextval('staging_origin1_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin2 ALTER COLUMN id SET DEFAULT nextval('staging_origin2_id_seq'::regclass);


--
-- Name: pk_client; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY client
    ADD CONSTRAINT pk_client PRIMARY KEY (id);


--
-- Name: pk_consumption; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumption
    ADD CONSTRAINT pk_consumption PRIMARY KEY (id);


--
-- Name: pk_meter_load; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY meter_load
    ADD CONSTRAINT pk_meter_load PRIMARY KEY (id);


--
-- Name: pk_staging_agl1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_agl1
    ADD CONSTRAINT pk_staging_agl1 PRIMARY KEY (id);


--
-- Name: pk_staging_origin1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin1
    ADD CONSTRAINT pk_staging_origin1 PRIMARY KEY (id);


--
-- Name: pk_staging_origin2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY staging_origin2
    ADD CONSTRAINT pk_staging_origin2 PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

